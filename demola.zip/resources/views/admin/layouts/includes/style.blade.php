
{{-- <link rel="stylesheet" href="{{ asset('dashboard/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/font-awesome.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/line-awesome.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/owl.theme.default.min.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/magnific-popup.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/daterangepicker.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/jquery-ui.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/jquery.filer.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/jquery.filer-dragdropbox-theme.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/nice-select.css') }}">
<link rel="stylesheet" href="{{ asset('dashboard/css/style.css') }}"> --}}
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css">

	
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.min.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<![endif]-->
	<style>
        h1{
            background-color:pink;
        }
        </style>
	<!-- All PLUGINS CSS ============================================= -->
	<link rel="stylesheet" type="text/css" href="{{ asset('dashboard/assets/css/assets.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('dashboard/assets/vendors/calendar/fullcalendar.css') }}">
	
	<!-- TYPOGRAPHY ============================================= -->
	<link rel="stylesheet" type="text/css" href="{{ asset('dashboard/assets/css/typography.css') }}">
	
	<!-- SHORTCODES ============================================= -->
	<link rel="stylesheet" type="text/css" href="{{ asset('dashboard/assets/css/shortcodes/shortcodes.css') }}">
	
	<!-- STYLESHEETS ============================================= -->
	<link rel="stylesheet" type="text/css" href="{{ asset('dashboard/assets/css/style.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('dashboard/assets/css/dashboard.css') }}">
	<link class="skin" rel="stylesheet" type="text/css" href="{{ asset('dashboard/assets/css/color/color-1.css') }}">